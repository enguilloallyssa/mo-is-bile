import 'package:flutter/material.dart';

/// Shared entry point for the Rider shell's navigation drawer.
class RiderMenuController {
  static VoidCallback? open;
}

class RiderMenuButton extends StatelessWidget {
  const RiderMenuButton({
    super.key,
  });

  void _openMenu(
    BuildContext context,
  ) {
    ScaffoldState? targetScaffold;

    context.visitAncestorElements(
      (Element element) {
        final Widget widget = element.widget;

        if (widget is Scaffold &&
            widget.endDrawer != null &&
            element is StatefulElement &&
            element.state is ScaffoldState) {
          targetScaffold = element.state as ScaffoldState;
          return false;
        }

        return true;
      },
    );

    if (targetScaffold != null) {
      targetScaffold!.openEndDrawer();
      return;
    }

    final VoidCallback? callback = RiderMenuController.open;
    if (callback != null) {
      callback();
      return;
    }

    ScaffoldMessenger.maybeOf(context)?.showSnackBar(
      const SnackBar(
        content: Text('Rider menu is not connected to the current page.'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: 'Open Rider menu',
      padding: EdgeInsets.zero,
      constraints: const BoxConstraints(minWidth: 40, minHeight: 40),
      iconSize: 20,
      color: RiderColors.text,
      onPressed: () => _openMenu(context),
      icon: const Icon(Icons.menu_rounded),
    );
  }
}

/// Rider-only UI navigation callbacks set by RiderShell.
class RiderHeaderController {
  static VoidCallback? messages;
  static VoidCallback? notifications;
}

class RiderHeaderActions extends StatelessWidget {
  const RiderHeaderActions({super.key, this.unreadMessages = 0});

  /// Uses the existing server summary; no separate polling is introduced.
  final int unreadMessages;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _headerIcon(
          tooltip: 'Messages',
          icon: Icons.chat_bubble_outline_rounded,
          onPressed: RiderHeaderController.messages,
          count: unreadMessages,
        ),
        const SizedBox(width: 8),
        _headerIcon(
          tooltip: 'Notifications',
          icon: Icons.notifications_none_rounded,
          onPressed: RiderHeaderController.notifications,
        ),
        const SizedBox(width: 8),
        Padding(
          padding: const EdgeInsets.only(right: 4),
          child: Builder(
            builder: (context) => Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: RiderColors.surface,
                borderRadius: BorderRadius.circular(13),
                border: Border.all(color: RiderColors.border),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(
                      alpha: RiderColors.isDark ? .18 : .04,
                    ),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: const RiderMenuButton(),
            ),
          ),
        ),
      ],
    );
  }

  Widget _headerIcon({
    required String tooltip,
    required IconData icon,
    required VoidCallback? onPressed,
    int count = 0,
  }) {
    return SizedBox(
      width: 40,
      height: 40,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.center,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: RiderColors.surface,
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: RiderColors.border),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(
                    alpha: RiderColors.isDark ? .18 : .04,
                  ),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: IconButton(
              tooltip: tooltip,
              onPressed: onPressed,
              padding: EdgeInsets.zero,
              icon: Icon(icon, size: 20, color: RiderColors.text),
            ),
          ),
          if (count > 0)
            Positioned(
              right: -3,
              top: -3,
              child: IgnorePointer(
                child: Container(
                  constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: RiderColors.gold,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: RiderColors.surface, width: 1.8),
                  ),
                  child: Text(
                    count > 9 ? '9+' : '$count',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 9,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class RiderSearchField extends StatelessWidget {
  const RiderSearchField({
    super.key,
    required this.controller,
    required this.hintText,
    required this.onChanged,
    this.onSubmitted,
  });

  final TextEditingController controller;
  final String hintText;
  final ValueChanged<String> onChanged;
  final ValueChanged<String>? onSubmitted;

  @override
  Widget build(BuildContext context) => TextField(
        controller: controller,
        onChanged: onChanged,
        onSubmitted: onSubmitted,
        textInputAction: onSubmitted == null
            ? TextInputAction.done
            : TextInputAction.search,
        style: TextStyle(
          color: RiderColors.text,
          fontSize: 13.5,
          fontWeight: FontWeight.w600,
        ),
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: TextStyle(
            color: RiderColors.muted,
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
          prefixIcon: Icon(
            Icons.search_rounded,
            color: RiderColors.muted,
            size: 20,
          ),
          suffixIcon: controller.text.isEmpty
              ? null
              : IconButton(
                  tooltip: 'Clear search',
                  icon: Icon(
                    Icons.close_rounded,
                    size: 18,
                    color: RiderColors.muted,
                  ),
                  onPressed: () {
                    controller.clear();
                    onChanged('');
                  },
                ),
          filled: true,
          fillColor: RiderColors.surface,
          isDense: true,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: RiderColors.border),
            borderRadius: BorderRadius.circular(16),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: RiderColors.gold, width: 1.6),
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      );
}

class RiderThemeController {
  static bool isDark = false;

  static void setDark(bool value) {
    isDark = value;
  }
}

class RiderColors {
  static bool get isDark => RiderThemeController.isDark;

  static Color get bg =>
      isDark ? const Color(0xFF121210) : const Color(0xFFF7F5F0);

  static Color get surface =>
      isDark ? const Color(0xFF1C1B18) : const Color(0xFFFFFFFF);

  static Color get surfaceElevated =>
      isDark ? const Color(0xFF24221E) : const Color(0xFFFFFFFF);

  static Color get surfaceSoft =>
      isDark ? const Color(0xFF2C2923) : const Color(0xFFF1EDE4);

  static Color get text =>
      isDark ? const Color(0xFFF6F5F2) : const Color(0xFF161513);

  static Color get muted =>
      isDark ? const Color(0xFFA39E93) : const Color(0xFF6E6A63);

  static Color get border =>
      isDark ? const Color(0xFF36322B) : const Color(0xFFE6E0D5);

  static Color get nav =>
      isDark ? const Color(0xFF1A1916) : const Color(0xFFFFFFFF);

  static Color get field =>
      isDark ? const Color(0xFF25231E) : const Color(0xFFFBF9F5);

  static Color get overlay =>
      isDark ? const Color(0x660D0D0C) : const Color(0x44FFFFFF);

  static Color get gold =>
      isDark ? const Color(0xFFF2B84B) : const Color(0xFFD4952A);

  static Color get goldDark =>
      isDark ? const Color(0xFFFFCC66) : const Color(0xFF9E6B14);

  static Color get goldSoft =>
      isDark ? const Color(0xFF3D3220) : const Color(0xFFFFF3D6);

  static Color get blue =>
      isDark ? const Color(0xFF58B4F5) : const Color(0xFF1D74B8);

  static Color get blueSoft =>
      isDark ? const Color(0xFF1D3347) : const Color(0xFFE6F2FC);

  static Color get green =>
      isDark ? const Color(0xFF4ADE80) : const Color(0xFF15803D);

  static Color get greenSoft =>
      isDark ? const Color(0xFF193827) : const Color(0xFFE3F9EB);

  static Color get red =>
      isDark ? const Color(0xFFF87171) : const Color(0xFFC83A3A);

  static Color get redSoft =>
      isDark ? const Color(0xFF422123) : const Color(0xFFFDECEC);

  static Color get purple =>
      isDark ? const Color(0xFFB794F4) : const Color(0xFF6D48C7);

  static Color get purpleSoft =>
      isDark ? const Color(0xFF322745) : const Color(0xFFF0EBFA);

  static List<Color> get heroGradient => isDark
      ? const <Color>[
          Color(0xFF181714),
          Color(0xFF27221A),
          Color(0xFF4A391E),
        ]
      : const <Color>[
          Color(0xFF181715),
          Color(0xFF2C251B),
          Color(0xFF6E501E),
        ];

  static List<Color> get earningsGradient => isDark
      ? const <Color>[
          Color(0xFF221F1A),
          Color(0xFF332B1F),
        ]
      : const <Color>[
          Color(0xFFFFFFFF),
          Color(0xFFF7F4EC),
        ];
}

class RiderHeaderTitle extends StatelessWidget {
  final String title;
  final String subtitle;

  const RiderHeaderTitle({
    super.key,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Text(
          title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: RiderColors.text,
            fontSize: 18.5,
            fontWeight: FontWeight.w900,
            letterSpacing: -.4,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          subtitle,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: RiderColors.muted,
            fontSize: 11.5,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

class RiderSurface extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? color;
  final double radius;
  final bool shadow;
  final bool elevated;

  const RiderSurface({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.color,
    this.radius = 20,
    this.shadow = false,
    this.elevated = false,
  });

  @override
  Widget build(BuildContext context) {
    final Color background = color ??
        (elevated ? RiderColors.surfaceElevated : RiderColors.surface);

    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: RiderColors.border),
        boxShadow: (shadow || elevated)
            ? <BoxShadow>[
                BoxShadow(
                  color: Colors.black.withValues(
                    alpha: RiderColors.isDark
                        ? .22
                        : (shadow ? .06 : .03),
                  ),
                  blurRadius: shadow ? 18 : 12,
                  offset: Offset(0, shadow ? 6 : 3),
                ),
              ]
            : null,
      ),
      child: child,
    );
  }
}

class RiderStatusPill extends StatelessWidget {
  final String label;
  final Color color;
  final Color background;
  final IconData? icon;

  const RiderStatusPill({
    super.key,
    required this.label,
    required this.color,
    required this.background,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withValues(alpha: .22)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          if (icon != null) ...[
            Icon(icon, size: 13, color: color),
            const SizedBox(width: 5),
          ],
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: color,
                fontSize: 10.5,
                fontWeight: FontWeight.w800,
                letterSpacing: .2,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class RiderSectionHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? trailing;

  const RiderSectionHeader({
    super.key,
    required this.title,
    this.subtitle,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                title,
                style: TextStyle(
                  color: RiderColors.text,
                  fontSize: 17,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -.3,
                ),
              ),
              if (subtitle != null) ...[
                const SizedBox(height: 2),
                Text(
                  subtitle!,
                  style: TextStyle(
                    color: RiderColors.muted,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w500,
                    height: 1.35,
                  ),
                ),
              ],
            ],
          ),
        ),
        if (trailing != null) ...[
          const SizedBox(width: 10),
          trailing!,
        ],
      ],
    );
  }
}

class RiderMetricTile extends StatelessWidget {
  final String value;
  final String label;
  final IconData icon;
  final Color accent;
  final Color softColor;

  const RiderMetricTile({
    super.key,
    required this.value,
    required this.label,
    required this.icon,
    required this.accent,
    required this.softColor,
  });

  @override
  Widget build(BuildContext context) {
    final Color iconBackground =
        RiderColors.isDark ? accent.withValues(alpha: .16) : softColor;

    return RiderSurface(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 14),
      radius: 18,
      elevated: true,
      child: Row(
        children: <Widget>[
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: iconBackground,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: accent, size: 19),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: RiderColors.text,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -.4,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: RiderColors.muted,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class RiderEmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;

  const RiderEmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
  });

  @override
  Widget build(BuildContext context) {
    return RiderSurface(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 34),
      radius: 22,
      elevated: true,
      child: Column(
        children: <Widget>[
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: RiderColors.goldSoft,
              shape: BoxShape.circle,
              border: Border.all(
                color: RiderColors.gold.withValues(alpha: .25),
              ),
            ),
            child: Icon(
              icon,
              color: RiderColors.goldDark,
              size: 27,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: RiderColors.text,
              fontSize: 15.5,
              fontWeight: FontWeight.w900,
              letterSpacing: -.2,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            message,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: RiderColors.muted,
              fontSize: 12,
              height: 1.45,
            ),
          ),
        ],
      ),
    );
  }
}

Color riderStatusColor(String status) {
  if (status == 'completed' || status == 'delivered') {
    return RiderColors.green;
  }
  if (status == 'delivery_failed') {
    return RiderColors.red;
  }
  if (status.contains('sorting') || status.contains('delivery_')) {
    return RiderColors.blue;
  }
  return RiderColors.goldDark;
}

Color riderStatusSoftColor(String status) {
  if (status == 'completed' || status == 'delivered') {
    return RiderColors.greenSoft;
  }
  if (status == 'delivery_failed') {
    return RiderColors.redSoft;
  }
  if (status.contains('sorting') || status.contains('delivery_')) {
    return RiderColors.blueSoft;
  }
  return RiderColors.goldSoft;
}